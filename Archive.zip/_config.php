<?php
/*** configuration *****/
ini_set('display_errors','on');
error_reporting(E_ALL);
$root = $_SERVER['DOCUMENT_ROOT'];
define('ROOT', $root);
